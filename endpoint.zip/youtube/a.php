<script>
var json ={
    "m": "",
    "d": {
        "e": [
            {
                "k": "login",
                "m": "__10_10"
            }
        ]
    },
    "s": "false",
    "t": "v"
};

 json =JSON.stringify(json); // this converts it into JSON parsable
console.log(JSON.parse(json));
//var b=JSON.encode(json);
// console.log(JSON.parse(b));
</script>
module.exports = {

	'secret': 'ilovescotchyscotch',

};